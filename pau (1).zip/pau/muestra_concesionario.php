<?php
  include("libs/connectionBD.php");

  $id_concesionario = $_GET['id_concesionario'];

  $sql = "SELECT * FROM cat_concesionario WHERE id_concesionario = $id_concesionario";
  $result = mysqli_query($conn, $sql);

  while($row = mysqli_fetch_assoc($result)) {
    $nombre = $row["nombre"];
    $calle = $row["dir_calle"];
    $colonia = $row["dir_colonia"];
    $cp = $row["dir_cp"];
    $edo = $row["dir_edo"];
  }

 ?>


 <!DOCTYPE html>
 <html>
 <header>
 <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
   <script src="bootstrap/js/bootstrap.js"></script>
</header>

 <body>
<div class="container mt-3">
  <form action="edita_concesionario.php" method="post">
    <label for="tnombre">Nombre: </label><br>
    <input type="text" id="tnombre" name="tnombre" value = "<?php echo $nombre; ?>" required><br>
    <label for="calle">Calle: </label><br>
    <input type="text" id="calle" name="calle" value = "<?php echo $calle; ?>" required><br>
    <label for="colonia">Colonia: </label><br>
    <input type="text" id="colonia" name="colonia" value = "<?php echo $colonia; ?>" required><br>
    <label for="cp">Codigo Postal: </label><br>
    <input type="text" id="cp" name="cp" value = "<?php echo $cp; ?>" required><br>
    <label for="edo">Estado: </label><br>
    <input type="text" id="edo" name="edo" value = "<?php echo $edo; ?> "required><br>
    <input type="hidden" id="id_concesionario" name = "id_concesionario" value = "<?php echo $id_concesionario;?> ">
    <input type="submit" value="Submit">
  </form>
</div>
</body>
</html>
