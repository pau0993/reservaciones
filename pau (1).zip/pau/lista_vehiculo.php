<?php
  include("libs/connectionBD.php");

  $sql = "SELECT * FROM cat_vehiculo";
  $result = mysqli_query($conn, $sql);

 ?>

 <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
   <script src="bootstrap/js/bootstrap.js"></script>


<div class="container mt-3">
 <table class="table table-striped">
  <tr>
    <th>Marca</th>
    <th>Submarca</th>
    <th>Modelo</th>
    <th>Color</th>
    <th>Numero de Serie</th>
    <th>Editar</th>
  </tr>

      <?php
      while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>".$row["marca"]. "</td>";
        echo "<td>".$row["submarca"]."</td>";
        echo "<td>".$row["modelo"]."</td>";
        echo "<td>".$row["color"]."</td>";
        echo "<td>".$row["no_serie"]."</td>";
        echo "<td> <a href='muestra_vehiculo.php?id_vehiculo=".$row['id_vehiculo']."'> Editar </a> </td>";
        echo "</tr>";
      }
       ?>
</table>
</div>

<?php
mysqli_close($conn);
?>
