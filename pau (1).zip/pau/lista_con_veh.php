<?php
include ("libs/connectionBD.php");

$CONSULTA_VEH_CONC = "SELECT a.id_lista_veh_conc, b.nombre as concesionario_nombre, b.dir_calle as calle, b.dir_colonia as colonia,
                        b.dir_cp as cp, b.dir_edo as edo, c.nombre as marca_nombre, d.submarca as submarca
                        FROM lista_veh_conc a, cat_concesionario b, cat_marca c, cat_vehiculo d
                        where a.id_concesionario = ".$_GET['concesionario']."
                        and a.id_concesionario = b.id_concesionario
                        and a.id_marca = c.id_marca
                        and a.id_vehiculo = d.id_vehiculo";

$result = mysqli_query($conn, $CONSULTA_VEH_CONC);
?>


 <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
   <script src="bootstrap/js/bootstrap.js"></script>


<div class="container mt-3">
 <table class="table table-striped">
  <tr>
    <th>Concesionario</th>
    <th>Calle</th>
    <th>Colonia</th>
    <th>Codigo Postal</th>
    <th>Estado</th>
    <th>Marca</th>
    <th>Vehiculo</th>
  </tr>

      <?php
      while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>".$row["concesionario_nombre"]. "</td>";
        echo "<td>".$row["calle"]. "</td>";
        echo "<td>".$row["colonia"]. "</td>";
        echo "<td>".$row["cp"]. "</td>";
        echo "<td>".$row["edo"]. "</td>";
        echo "<td>".$row["marca_nombre"]."</td>";
        echo "<td>".$row["submarca"]."</td>";
        echo "</tr>";
      }
       ?>
</table>
</div>

<?php
mysqli_close($conn);
?>
