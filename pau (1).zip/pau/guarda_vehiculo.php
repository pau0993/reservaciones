<?php
include ("libs/connectionBD.php");

$marca = $_POST["marca"];
$submarca = $_POST["submarca"];
$modelo = $_POST["modelo"];
$color = $_POST["color"];
$no_serie = $_POST["no_serie"];


$GRABAR_SQL = "INSERT INTO cat_vehiculo VALUES (0,'$marca','$submarca','$modelo','$color', '$no_serie', 0,0)";
//echo $GRABAR_SQL;
if (mysqli_query($conn, $GRABAR_SQL)) {
  header("Location: lista_vehiculo_boot.php");
exit();
} else {
  echo "Error: " . $GRABAR_SQL. "<br>" . mysqli_error($conn);
}

?>
