<?php
  include("libs/connectionBD.php");


 ?>
 <!DOCTYPE html>
 <html>
 <header>
 <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
   <script src="bootstrap/js/bootstrap.js"></script>
</header>

 <body>
<div class="container mt-3">
  <form action="guarda_concesionario.php" method="post">
    <label for="tnombre">Nombre: </label><br>
    <input type="text" id="tnombre" name="tnombre" required><br>
    <label for="calle">Calle: </label><br>
    <input type="text" id="calle" name="calle" required><br>
    <label for="colonia">Colonia: </label><br>
    <input type="text" id="colonia" name="colonia" required><br>
    <label for="cp">Codigo Postal: </label><br>
    <input type="text" id="cp" name="cp" required><br>
    <label for="edo">Estado: </label><br>
    <input type="text" id="edo" name="edo" required><br>

    <input type="submit" value="Submit">
  </form>
</div>
</body>
</html>
