<?php
include ("libs/connectionBD.php");

$id_concesionario = $_POST["concesionario"];
$id_marca = $_POST["country"];
$id_vehiculo = $_POST["city"];


$GRABAR_SQL = "INSERT INTO lista_veh_conc VALUES (0,$id_concesionario,$id_marca,$id_vehiculo,1)";
//echo $GRABAR_SQL;
if (mysqli_query($conn, $GRABAR_SQL)) {
  header("Location: asociar_veh_conc_boot.php");
exit();
} else {
  echo "Error: " . $GRABAR_SQL. "<br>" . mysqli_error($conn);
}

?>
