<?php
  include("libs/connectionBD.php");

  $sql = "SELECT * FROM cat_concesionario";
  $result = mysqli_query($conn, $sql);

 ?>

 <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
   <script src="bootstrap/js/bootstrap.js"></script>


<div class="container mt-3">
 <table class="table table-striped">
  <tr>
    <th>Nombre Concesionario</th>
    <th>Calle</th>
    <th>Colonia</th>
    <th>Código Postal</th>
    <th>Estado</th>
    <th>Editar</th>
  </tr>

      <?php
      while($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>".$row["nombre"]. "</td>";
        echo "<td>".$row["dir_calle"]."</td>";
        echo "<td>".$row["dir_colonia"]."</td>";
        echo "<td>".$row["dir_cp"]."</td>";
        echo "<td>".$row["dir_edo"]."</td>";
        echo "<td> <a href='muestra_concesionario.php?id_concesionario=".$row['id_concesionario']."'> Editar </a> </td>";
        echo "</tr>";
      }
       ?>
</table>
</div>

<?php
mysqli_close($conn);
?>
