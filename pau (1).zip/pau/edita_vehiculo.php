<?php
include ("libs/connectionBD.php");

$marca = $_POST["marca"];
$submarca = $_POST["submarca"];
$modelo = $_POST["modelo"];
$color = $_POST["color"];
$no_serie = $_POST["no_serie"];
$id_vehiculo = $_POST["id_vehiculo"];

$UPDATE_SQL = "UPDATE cat_vehiculo SET id_marca= '$marca', submarca = '$submarca', modelo = '$modelo',
              color = '$color', no_serie = '$no_serie' WHERE id_vehiculo = $id_vehiculo LIMIT 1";
if (mysqli_query($conn, $UPDATE_SQL)) {
  header("Location: lista_vehiculo_boot.php");
exit();
} else {
  echo "Error: " . $UPDATE_SQL. "<br>" . mysqli_error($conn);
}

?>
