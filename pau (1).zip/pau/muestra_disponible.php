<?php
  include("libs/connectionBD.php");

  $sql = "SELECT a.id_marca as marca, a.submarca as submarca, a.modelo as modelo, a.color as color, a.no_serie as no_serie,
              b.f_inicio as fecha_inicio, b.f_fin as fecha_fin
              FROM cat_vehiculo a LEFT outer JOIN calendario b ON a.id_vehiculo = b.id_vehiculo
              WHERE b.id_calendario is null
              OR b.f_inicio NOT BETWEEN '".$_POST['f_inicio']."' and '".$_POST['f_fin']."'
              AND b.f_fin NOT BETWEEN '".$_POST['f_inicio']."' and '".$_POST['f_fin']."'";

  $result = mysqli_query($conn, $sql);



 ?>


 <!DOCTYPE html>
 <html>
 <header>
 <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
   <script src="bootstrap/js/bootstrap.js"></script>
</header>

 <body>
<div class="container mt-3">
  <table>
    <tr>
      <td>Marca </td>
      <td>Submarca </td>
      <td>Modelo </td>
      <td>Color </td>
      <td>No. Serie </td>
      <td>Fecha Inicio </td>
      <td>Fecha Fin </td>
      <td>Concesionario </td>
    </tr>
<?php
while($row = mysqli_fetch_assoc($result)) {
  $marca = $row["marca"];
  $submarca = $row["submarca"];
  $modelo = $row["modelo"];
  $color = $row["color"];
  $no_serie = $row["no_serie"];
  $f_inicio = $row["fecha_inicio"];
  $f_fin = $row["fecha_fin"];

  /*
  otro query
  */

  echo "<tr>";
  echo "<td> ".$marca."</td>";
  echo "<td> ".$submarca."</td>";
  echo "<td> ".$modelo."</td>";
  echo "<td> ".$color."</td>";
  echo "<td> ".$no_serie."</td>";
  echo "<td> ".$f_inicio."</td>";
  echo "<td> ".$f_fin."</td>";
  echo "<td> conce ".$f_fin."</td>";
  echo "</tr>";

}
?>


  </table>
</div>
</body>
</html>
