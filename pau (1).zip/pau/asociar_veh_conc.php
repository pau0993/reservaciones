<?php
include ("libs/connectionBD.php");
?>


<html>
<body>
  <div align="center">

    <p>Elige concesionario:
      <form action="guarda_asociacion.php" method="post">
      <select name="concesionario">
          <option value="0">Selecciona:</option>
          <?php
            $lista_concesionario = "SELECT id_concesionario, nombre from cat_concesionario";
            $valores = mysqli_query($conn, $lista_concesionario);

            while($row = mysqli_fetch_assoc($valores))
            {
              echo '<option value="'.$row['id_concesionario'].'">'.$row['nombre'].'</option>';
            }
          ?>
        </select>
      </p>

      <br>
      <p>Elige marca:

        <select name="country" class="country">
            <option value="0">Selecciona:</option>
            <?php
              $lista_marca = "SELECT id_marca, nombre FROM cat_marca";
              $valores = mysqli_query($conn, $lista_marca);

              while($row = mysqli_fetch_assoc($valores))
              {
                echo '<option value="'.$row['id_marca'].'">'.$row['nombre'].'</option>';
              }
            ?>
          </select>
        </p>
      </br>
      <label>Modelo :</label>
      <select name="city" class="city">
      <option>Select City</option>
      </select>
        <button>Enviar</button>
      </form>
  </div>
  
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

  <script type="text/javascript">
    $(document).ready(function()
    {
    $(".country").change(function()
    {
    var country_id = $(this).val();
    alert(country_id);
    var post_id = 'id='+ country_id;
    alert(post_id);
    $.ajax
    ({
    type: "POST",
    url: "ajax_submarca.php",
    data: post_id,
    cache: false,
    success: function(cities)
    {
    $(".city").html(cities);
    }
    });

    });
    });
  </script>
</body>
</html>
