<?php

function drop_down_selected($query, $nombre, $id, $javascript,$campo1,$campo2,$class, $selected, $opciones)
{

        $servername = "localhost";
        $username = "cowandufo_pau";
        $password = "6lF40ZyMzd";
        $dbname = "cowandufo_pau";

        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        // Check connection
        if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
        }

        $result=mysqli_query($conn, $query);
        //echo "$selected <br>";
        echo "<select name=\"$nombre\" id=\"$id\"  $javascript class=\"$class\" $opciones>
                        <option value=\"\"> -- Seleccionar -- </option>";
        while($row=mysqli_fetch_array($result))
        {

                if ($row[$campo1] == $selected )
                {
                        echo "<option value=".$row[$campo1]." selected >".$row[$campo2]."</option>";
                }
                 else
                {
                        echo "<option value=".$row[$campo1]." >".$row[$campo2]."</option>";
                }
        }

        echo"</select>";
}
?>
