<?php
  include("libs/connectionBD.php");
?>


<!DOCTYPE html>
<html>
<body>

    <form action="guarda_calendario.php" method="post">

    <h1>Reservaciones de un vehiculo</h1>

  <label for="f_inicio">Fecha de inicio:</label>
  <input type="date" id="f_inicio" name="f_inicio">

<br>
<br>

  <label for="f_fin">Fecha fin:</label>
  <input type="date" id="f_fin" name="f_fin">

<br>
<br>

<p>Elige marca:
  <select name="marca" class="marca">
      <option value="0">Selecciona:</option>
      <?php
        $lista_marca = "SELECT id_marca, nombre FROM cat_marca";
        $valores = mysqli_query($conn, $lista_marca);

        while($row = mysqli_fetch_assoc($valores))
        {
          echo '<option value="'.$row['id_marca'].'">'.$row['nombre'].'</option>';
        }
      ?>
    </select>
  </p>

  <br>
  <br>

  <label>Submarca:</label>
  <select name="submarca" class="submarca">
  <option>Selecciona</option>
  </select>
    <button>Enviar</button>
</div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<script type="text/javascript">
$(document).ready(function()
{
$(".marca").change(function()
{
var marca_id = $(this).val();
//alert(country_id);
var post_id = 'id='+ marca_id;
//alert(post_id);
$.ajax
({
type: "POST",
url: "ajax_submarca.php",
data: post_id,
cache: false,
success: function(submarcas)
{
$(".submarca").html(submarcas);
}
});

});
});
</script>
</form>
</body>
</html>
