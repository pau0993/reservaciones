<ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
  <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
    <a class="nav-link" href="index.php">
      <i class="fa fa-fw fa-dashboard"></i>
      <span class="nav-link-text">Dashboard</span>
    </a>
  </li>

  <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Charts">
    <a class="nav-link" href="lista_vehiculo_boot.php">
      <i class="fa fa-check-square"></i>
      <span class="nav-link-text">Catálogo Vehículos</span>
    </a>
  </li>
  <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Charts">
    <a class="nav-link" href="lista_concesionario_boot.php">
      <i class="fa fa-check-square"></i>
      <span class="nav-link-text">Catálogo Concesiones</span>
    </a>
  </li>
  <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Charts">
    <a class="nav-link" href="asociar_veh_conc_boot.php">
      <i class="fa fa-check-square"></i>
      <span class="nav-link-text">Asoc. Vehículo Concesionario</span>
    </a>
  </li>



</ul>
