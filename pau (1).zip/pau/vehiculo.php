<?php
  include("libs/connectionBD.php");
 ?>


 <!DOCTYPE html>
 <html>
 <header>
 <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
   <script src="bootstrap/js/bootstrap.js"></script>
</header>

 <body>
<div class="container mt-3">
  <form action="guarda_vehiculo.php" method="post">
    <label for="marca">Marca: </label><br>
    <input type="text" id="marca" name="marca" required><br>
    <label for="submarca">Submarca: </label><br>
    <input type="text" id="submarca" name="submarca" required><br>
    <label for="modelo">Modelo: </label><br>
    <input type="number" id="modelo" name="modelo" required><br>
    <label for="color">Color: </label><br>
    <input type="text" id="color" name="color" required><br>
    <label for="no_serie">No. serie: </label><br>
    <input type="text" id="no_serie" name="no_serie" required><br>

    <input type="submit" value="Submit">
  </form>
</div>
</body>
</html>
