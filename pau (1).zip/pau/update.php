<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

  include('libs/connectionBD.php');




if(isset($_GET['id_vehiculo']) && !empty($_GET['id_vehiculo']))
{
    $id_vehiculo = $_GET['id_vehiculo'];
    $id_concesionario = $_GET['concesionario'];
    $f_inicio = $_GET['f_inicio'];
    $f_fin = $_GET['f_fin'];
    $id_marca = $_GET['marca'];
    //echo $id_vehiculo;


    //$GRABAR_SQL = "INSERT INTO calendario VALUES (0,'$f_inicio','$f_fin','$id_marca','$id_vehiculo', 1)";
    $inserta = "INSERT INTO calendario (id_calendario, f_inicio, f_fin, id_marca, id_vehiculo, status)
                VALUES (0, '$f_inicio' , '$f_fin', $id_marca, $id_vehiculo, 1)";
    //echo "$inserta <br>";


    if (mysqli_query($conn, $inserta))
    {
        header("Location: index.php");
    }
    else
    {
        echo "Error updating record: =( $inserta " . mysqli_error($connect);
    }
    die;
}
?>
