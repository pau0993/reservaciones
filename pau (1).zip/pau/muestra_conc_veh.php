<?php
include ("libs/connectionBD.php");
?>


<html>
<body>
  <div align="center">

    <p>Elige concesionario:
      <form action="lista_con_veh.php" method="post">
      <select name="concesionario">
          <option value="0">Selecciona:</option>
          <?php
            $lista_concesionario = "SELECT id_concesionario, nombre from cat_concesionario";
            $valores = mysqli_query($conn, $lista_concesionario);

            while($row = mysqli_fetch_assoc($valores))
            {
              echo '<option value="'.$row['id_concesionario'].'">'.$row['nombre'].'</option>';
            }
          ?>
        </select>
        <button> Enviar </button>
      </form>
      </p>
    </div>
  </body>
  </html>
