<?php
include ("libs/connectionBD.php");

$tnombre = $_POST["tnombre"];
$calle = $_POST["calle"];
$colonia = $_POST["colonia"];
$cp = $_POST["cp"];
$edo = $_POST["edo"];


$GRABAR_SQL = "INSERT INTO cat_concesionario VALUES (0,'$tnombre','$calle','$colonia','$cp','$edo',1)";
echo $GRABAR_SQL;
if (mysqli_query($conn, $GRABAR_SQL)) {
  header("Location: concesionario.php");
exit();
} else {
  echo "Error: " . $GRABAR_SQL. "<br>" . mysqli_error($conn);
}

?>
