<?php
include ("libs/connectionBD.php");

$nombre = $_POST["tnombre"];
$calle = $_POST["calle"];
$colonia = $_POST["colonia"];
$cp = $_POST["cp"];
$edo = $_POST["edo"];
$id_concesionario = $_POST["id_concesionario"];

$UPDATE_SQL = "UPDATE cat_concesionario SET nombre = '$nombre', dir_calle = '$calle', dir_colonia = '$colonia',
                dir_cp = '$cp', dir_edo = '$edo' WHERE id_concesionario = $id_concesionario LIMIT 1";
if (mysqli_query($conn, $UPDATE_SQL)) {
  header("Location: lista_concesionario_boot.php");
exit();
} else {
  echo "Error: " . $UPDATE_SQL. "<br>" . mysqli_error($conn);
}

?>
