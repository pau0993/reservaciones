<?php
include ("libs/connectionBD.php");

$f_inicio = $_POST["f_inicio"];
$f_fin = $_POST["f_fin"];
$id_marca = $_POST["marca"];
$id_vehiculo = $_POST["submarca"];


$GRABAR_SQL = "INSERT INTO calendario VALUES (0,'$f_inicio','$f_fin','$id_marca','$id_vehiculo', 1)";
echo $GRABAR_SQL;
if (mysqli_query($conn, $GRABAR_SQL)) {
  header("Location: calendario.php");
exit();
} else {
  echo "Error: " . $GRABAR_SQL. "<br>" . mysqli_error($conn);
}

?>
