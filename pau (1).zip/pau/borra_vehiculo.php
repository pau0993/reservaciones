<?php
include ("libs/connectionBD.php");

$id_vehiculo = $_GET["id_vehiculo"];

$borra_vehiculo = "DELETE FROM cat_vehiculo WHERE id_vehiculo = '$id_vehiculo' LIMIT 1";

if (mysqli_query($conn, $borra_vehiculo)) {
  header("Location: lista_vehiculo_boot.php");
exit();
} else {
  echo "Error: " . $borra_vehiculo. "<br>" . mysqli_error($conn);
}

?>
