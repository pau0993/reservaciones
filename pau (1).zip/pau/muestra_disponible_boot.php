<?php

  include("libs/connectionBD.php");


  $sql = "SELECT a.id_vehiculo as unico, a.id_marca as marca, a.submarca as submarca, a.modelo as modelo, a.color as color, a.no_serie as no_serie,
              b.f_inicio as fecha_inicio, b.f_fin as fecha_fin
              FROM cat_vehiculo a LEFT outer JOIN calendario b ON a.id_vehiculo = b.id_vehiculo
              WHERE b.id_calendario is null
              OR b.f_inicio NOT BETWEEN '".$_POST['f_inicio']."' and '".$_POST['f_fin']."'
              AND b.f_fin NOT BETWEEN '".$_POST['f_inicio']."' and '".$_POST['f_fin']."'";

  $result = mysqli_query($conn, $sql);
  $f_inicio = $_POST['f_inicio'];
  $f_fin = $_POST['f_fin'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>SB Admin - Start Bootstrap Template</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">


  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <!-- Page level plugin JavaScript-->
  <script src="vendor/datatables/jquery.dataTables.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin.min.js"></script>
  <!-- Custom scripts for this page-->
  <script src="js/sb-admin-datatables.min.js"></script>
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="index.html">Start Bootstrap</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">

      <?php include("sidebar.php"); ?>

    </div>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.html">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Vehiculos disponibles</li>
      </ol>
      <!-- Breadcrumbs-->

      <div class="row">
        <!-- Content here -->
        <div class="col-12">
          <h1>Vehiculos disponibles</h1>
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
            <tr>
              <td>Marca </td>
              <td>Submarca </td>
              <td>Modelo </td>
              <td>Color </td>
              <td>No. Serie </td>
              <td>Fecha Inicio </td>
              <td>Fecha Fin </td>
              <td>Concesionario </td>
              <td>Acción </td>
            </tr>
            </thead>
            <tfoot>
            <tr>
              <td>Marca </td>
              <td>Submarca </td>
              <td>Modelo </td>
              <td>Color </td>
              <td>No. Serie </td>
              <td>Fecha Inicio </td>
              <td>Fecha Fin </td>
              <td>Concesionario </td>
              <td>Reservar</td>
            </tr>
          </tfoot>
        <?php
        while($row = mysqli_fetch_assoc($result))
        {
          $marca = $row["marca"];
          $submarca = $row["submarca"];
          $modelo = $row["modelo"];
          $color = $row["color"];
          $no_serie = $row["no_serie"];
          $f_inicio = $row["fecha_inicio"];
          $f_fin = $row["fecha_fin"];
          $id_vehiculo = $row["unico"];


          $el_concesionario = "SELECT a.id_concesionario, b.nombre
                      FROM lista_veh_conc a, cat_concesionario b
                      where a.id_vehiculo = ".$id_vehiculo."
                      and a.id_concesionario = b.id_concesionario";
          $resultado = mysqli_query($conn, $el_concesionario);
          while($row_dos = mysqli_fetch_assoc($resultado))
          {
            $concesionario = $row_dos['nombre'];
            $id_concesionario = $row_dos['id_concesionario'];
          }

          $la_marca = "SELECT a.id_marca, b.nombre
                       FROM lista_veh_conc a, cat_marca b
                       WHERE a.id_vehiculo = ".$marca."
                       AND a.id_marca = b.id_marca ";
          $resultado_marca = mysqli_query($conn, $la_marca);
          while($row_tres = mysqli_fetch_assoc($resultado_marca))
          {
            $marca_vehiculo = $row_tres['nombre'];
          }


          echo "<tr>";
          echo "<td> ".$marca_vehiculo."</td>";
          echo "<td> ".$submarca."</td>";
          echo "<td> ".$modelo."</td>";
          echo "<td> ".$color."</td>";
          echo "<td> ".$no_serie."</td>";
          echo "<td> ".$f_inicio."</td>";
          echo "<td> ".$f_fin."</td>";
          echo "<td> ".$concesionario."</td>";
          echo "<td> <a href='update.php?id_vehiculo=".$id_vehiculo."&concesionario=$id_concesionario&marca=$marca&f_inicio=$f_inicio&f_fin=$f_fin'> Reservar </a>

                </td>";
          echo "</tr>";

        }
        ?>


          </table>
        </div>
        <!-- End content here -->
      </div>
    </div>


    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © Your Website 2018</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Modal -->
    <div class="modal fade" id="empModal" role="dialog">
                    <div class="modal-dialog">

                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              <h4 class="modal-title">User Info</h4>
                            </div>
                            <div class="modal-body">

                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>

                    </div>
      </div>


    <!-- End Modal-->

    <script type='text/javascript'>
                $(document).ready(function(){

                    $('.userinfo').click(function(){

                        var userid = $(this).data('id');
                        var fechafin = $(this).data('fecha_oculta');

                        // AJAX request
                        $.ajax({
                            url: 'update.php',
                            type: 'post',
                            data: {userid: userid, fechafin: fechafin},
                            success: function(response){
                                // Add response in Modal body
                                $('.modal-body').html(response);

                                // Display Modal
                                $('#empModal').modal('show');
                            }
                        });
                    });
                });
                </script>




    <script>
function updateId(id)
{
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            alert(xmlhttp.responseText);
        }
    };
    xmlhttp.open("GET", "update.php?id=" +id, true);
    xmlhttp.send();
}
</script>

  </div>
</body>

</html>
