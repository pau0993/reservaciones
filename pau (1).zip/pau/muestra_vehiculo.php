<?php
  include("libs/connectionBD.php");

  $id_vehiculo = $_GET['id_vehiculo'];

  $sql = "SELECT * FROM cat_vehiculo WHERE id_vehiculo = $id_vehiculo";
  $result = mysqli_query($conn, $sql);

  while($row = mysqli_fetch_assoc($result)) {
    $marca = $row["marca"];
    $submarca = $row["submarca"];
    $modelo = $row["modelo"];
    $color = $row["color"];
    $no_serie = $row["no_serie"];
  }

 ?>


 <!DOCTYPE html>
 <html>
 <header>
 <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
   <script src="bootstrap/js/bootstrap.js"></script>
</header>

 <body>
<div class="container mt-3">
  <form action="edita_vehiculo.php" method="post">
    <label for="marca">Marca: </label><br>
    <input type="text" id="marca" name="marca" value = "<?php echo $marca; ?>" required><br>
    <label for="calle">Submarca: </label><br>
    <input type="text" id="submarca" name="submarca" value = "<?php echo $submarca; ?>" required><br>
    <label for="modelo">Modelo: </label><br>
    <input type="int" id="modelo" name="modelo" value = "<?php echo $modelo; ?>" required><br>
    <label for="color">Color: </label><br>
    <input type="text" id="color" name="color" value = "<?php echo $color; ?>" required><br>
    <label for="no_serie">No. Serie: </label><br>
    <input type="text" id="no_serie" name="no_serie" value = "<?php echo $no_serie; ?> "required><br>
    <input type="hidden" id="id_vehiculo" name = "id_vehiculo" value = "<?php echo $id_vehiculo;?> ">
    <input type="submit" value="Submit">
  </form>
</div>
</body>
</html>
